import json
from datetime import datetime
from api_client import IndiaBondInfoClient
from data_processor import process_bond_data, write_cashflows_to_csv

def main():
    # Read ISINs from file
    input_file = "isins.json"
    output_file = "bond_cashflows.csv"
    
    try:
        with open(input_file, "r") as f:
            isin_entries = json.load(f)
    except FileNotFoundError:
        print(f"Error: {input_file} not found. Please create it with ISINs and investment dates.")
        return
    except json.JSONDecodeError:
        print(f"Error: Failed to parse {input_file}. Ensure it is valid JSON.")
        return
    
    if not isin_entries:
        print("No ISINs provided in isins.json.")
        return
    
    # Initialize API client
    client = IndiaBondInfoClient()
    
    # Process each ISIN
    all_cashflows = []
    for entry in isin_entries:
        isin = entry.get("isin")
        investment_date_str = entry.get("investment_date", "")
        number_of_units = entry.get("units", "")
        invested_amount_str = entry.get("invested_amount", "")
        if not isin or not investment_date_str or not number_of_units or not invested_amount_str:
            continue
        try:
            investment_date = datetime.strptime(investment_date_str, "%d-%m-%Y").date()
        except ValueError:
            print(f"Invalid date format for ISIN {isin}: {investment_date_str}")
            continue
        try:
            invested_amount = float(invested_amount_str) * -1
        except ValueError:
            print(f"Invalid invested amount or format for ISIN {isin}: {invested_amount_str}")
            continue
        print(f"Processing ISIN: {isin}")
        isin_data = client.fetch_isin_data(isin)
        coupon_data = client.fetch_coupon_data(isin)
        instruments_data = client.fetch_instruments_data(isin)
        
        if isin_data and coupon_data and instruments_data:
            cashflows = process_bond_data(isin, isin_data, coupon_data, instruments_data, investment_date, number_of_units, invested_amount)
            all_cashflows.extend(cashflows)
    
    # Write to CSV
    if all_cashflows:
        write_cashflows_to_csv(all_cashflows, output_file)
        print(f"CSV file '{output_file}' generated successfully.")
    else:
        print("No cash flow data to write.")

if __name__ == "__main__":
    main()