import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import time

class IndiaBondInfoClient:
    def __init__(self):
        self.isin_url = "https://indiabondinfo.nsdl.com/bds-service/v1/public/isins?isin={}"
        self.coupon_url = "https://indiabondinfo.nsdl.com/bds-service/v1/public/bdsinfo/coupondetail?isin={}"
        self.instruments_url = "https://indiabondinfo.nsdl.com/bds-service/v1/public/bdsinfo/instruments?isin={}"
        # Set up session with retries and minimal headers
        self.session = requests.Session()
        retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
        self.session.mount("https://", HTTPAdapter(max_retries=retries))
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json",
            "Connection": "keep-alive"
        })

    def fetch_isin_data(self, isin):
        try:
            response = self.session.get(self.isin_url.format(isin), timeout=10)
            response.raise_for_status()
            time.sleep(0.1)  # Delay to avoid rate limiting
            return response.json()
        except requests.RequestException as e:
            print(f"Error fetching ISIN data for {isin}: {e}")
            return {}

    def fetch_coupon_data(self, isin):
        try:
            response = self.session.get(self.coupon_url.format(isin), timeout=10)
            response.raise_for_status()
            time.sleep(0.1)  # Delay to avoid rate limiting
            return response.json()
        except requests.RequestException as e:
            print(f"Error fetching coupon data for {isin}: {e}")
            return {}

    def fetch_instruments_data(self, isin):
        try:
            response = self.session.get(self.instruments_url.format(isin), timeout=10)
            response.raise_for_status()
            time.sleep(0.1)  # Delay to avoid rate limiting
            return response.json()
        except requests.RequestException as e:
            print(f"Error fetching instruments data for {isin}: {e}")
            return {}