import csv
from datetime import datetime

def process_bond_data(isin, isin_data, coupon_data, instruments_data, investment_date, number_of_units, invested_amount):
    cashflows = []
    try:
        number_of_units = float(number_of_units)
    except ValueError:
        print(f"Invalid number of units for ISIN {isin}")
        return []
    
    # Extract data
    issuer = isin_data.get("issuerName", "Unknown")
    
    instruments = instruments_data.get("instrumentsVo", {}).get("instruments", {})
    face_value = float(instruments.get("faceValue", 0))
    maturity_date = instruments.get("redemptionDate", "")
    issue_price = float(instruments.get("issuePrice", 0))
    
    coupon_details = coupon_data.get("coupensVo", {}).get("couponDetails", {})
    coupon_rate = float(coupon_details.get("couponRate", 0).strip('%'))
    frequency = coupon_details.get("interestPaymentFrequency", "Unknown")
    
    cashflows.append({
        "ISIN": isin,
        "Issuer": issuer,
        "Units Count": number_of_units,
        "Investment Date": investment_date,
        "Record Date": "",
        "Cash Flow Date": investment_date,
        "Event Type": "Investment",
        "Coupon Rate (%)": "",
        "Maturity Date": "",
        "Face Value (₹)": "",
        "Frequency": "",
        "Issue Price (₹)": "",
        "Amount (₹)": invested_amount
    })
    
    cash_flows = coupon_data.get("coupensVo", {}).get("cashFlowScheduleDetails", {}).get("cashFlowSchedule", [])
    
    for cf in cash_flows:
        record_date_str = cf.get("recordDate", "").strip("-")
        if not record_date_str:
            record_date_str = datetime.strftime(investment_date, "%d-%m-%Y")
        try:
            record_date = datetime.strptime(record_date_str, "%d-%m-%Y").date()
        except ValueError:
            continue
        if record_date < investment_date:
            continue
        
        cashflow_date_str = cf.get("dueDate", "")
        if not cashflow_date_str:
            continue
        try:
            cashflow_date = datetime.strptime(cashflow_date_str, "%d-%m-%Y").date()
        except ValueError:
            continue
        
        event_type = cf.get("cashFlowsEvent", "")
        amount = float(cf.get("amountPayable", 0)) * number_of_units
        
        cashflows.append({
            "ISIN": isin,
            "Issuer": issuer,
            "Units Count": number_of_units,
            "Investment Date": investment_date,
            "Record Date": record_date,
            "Cash Flow Date": cashflow_date,
            "Event Type": event_type,
            "Coupon Rate (%)": coupon_rate,
            "Maturity Date": maturity_date,
            "Face Value (₹)": face_value,
            "Frequency": frequency,
            "Issue Price (₹)": issue_price,
            "Amount (₹)": amount
        })
    
    unique_cashflows = {(cf["ISIN"],cf["Cash Flow Date"],cf["Event Type"],cf["Amount (₹)"]): cf for cf in cashflows}
    return list(unique_cashflows.values())

def write_cashflows_to_csv(cashflows, output_file):
    headers = [
        "ISIN",
        "Issuer",
        "Units Count",
        "Investment Date",
        "Record Date",
        "Cash Flow Date",
        "Event Type",
        "Coupon Rate (%)",
        "Maturity Date",
        "Face Value (₹)",
        "Frequency",
        "Issue Price (₹)",
        "Amount (₹)"
    ]
    
    with open(output_file, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=headers)
        writer.writeheader()
        for cashflow in cashflows:
            writer.writerow(cashflow)